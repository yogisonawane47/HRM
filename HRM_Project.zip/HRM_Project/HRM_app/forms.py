from django import forms
from .models import Department,Roles
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm



class Departmentform(forms.ModelForm):
    class Meta:
        model = Department
        fields = ['Department_Name','Department_Description']
        widgets = {
            'Department_Name' : forms.TextInput(attrs={'class':'form-control'}),
            'Department_Description' : forms.TextInput(attrs={'class':'form-control'}),
        }

class userauthenticationForm (AuthenticationForm):
    username=forms.CharField(label="Enter username",widget=forms.TextInput(attrs={'class':'form-control'})),
    password=forms.CharField(label="Enter password",widget=forms.PasswordInput(attrs={'class':'form-control'})),   
    
    class Meta:
        model=User
        fields=['username','password']
 

class registrationform(UserCreationForm):
   
    username = forms.CharField(label='Enter Username' ,widget=forms.TextInput(attrs={'class':'form-control'}))
    
    first_name = forms.CharField(label='Enter First Name' ,widget=forms.TextInput(attrs={'class':'form-control'}))

    last_name = forms.CharField(label='Enter Last Name' ,widget=forms.TextInput(attrs={'class':'form-control'}))
    
    password1 = forms.CharField(label='Enter Password' ,widget=forms.PasswordInput(attrs={'class':'form-control'}))

    password2 = forms.CharField(label='Confirm Password' ,widget=forms.PasswordInput(attrs={'class':'form-control'}))

    email = forms.EmailField(
        label=("Email"),
        max_length=254,
        widget=forms.EmailInput(attrs={"class": "form-control"}),
    )

    class Meta:
        model = User
        fields = ['username' , 'first_name' , 'last_name' , 'email' , 'password1' , 'password2']

        labels = {
            'username':'Enter Username',
            'first_name' :'Enter First Name',
            'last_name' : 'Enter Last Name',
            'email' :'Enter Email-ID',
        }

        widgets = {
            'username' : forms.TextInput(attrs={'class':'form-control'}),
            'first_name':forms.TextInput(attrs={'class':'form-control'}),
            'last_name':forms.TextInput(attrs={'class':'form-control'}),
           
        } 


class Rolesform(forms.ModelForm):
    class Meta:
        model = Roles
        fields = ['role_name','role_description']
        widgets = {
            'role_name' : forms.TextInput(attrs={'class':'form-control'}),
            'role_description' : forms.TextInput(attrs={'class':'form-control'}),
        }
